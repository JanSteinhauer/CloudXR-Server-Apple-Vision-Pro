//
//  ObjectTrackingManager.swift
//  My First AVP CloudXR Client
//
//  Manages ARKit object tracking session
//

import ARKit
import RealityKit
import QuartzCore

@MainActor
@Observable
class ObjectTrackingManager {
    var isImmersiveSpaceOpened = false

    let referenceObjectLoader = ReferenceObjectLoader()

    func didLeaveImmersiveSpace() {
        // Stop the provider; the provider that just ran in the
        // immersive space is now in a paused state and isn't needed
        // anymore. When a person reenters the immersive space,
        // run a new provider.
        arkitSession.stop()
        isImmersiveSpaceOpened = false
    }

    // MARK: - ARKit state

    private var arkitSession = ARKitSession()

    private var objectTracking: ObjectTrackingProvider? = nil

    private var worldTracking: WorldTrackingProvider? = nil

    /// Current head/device pose in world space, or nil if unavailable.
    func currentHeadPose() -> simd_float4x4? {
        guard let worldTracking,
              worldTracking.state == .running,
              let deviceAnchor = worldTracking.queryDeviceAnchor(atTimestamp: CACurrentMediaTime()) else {
            return nil
        }
        return deviceAnchor.originFromAnchorTransform
    }

    var objectTrackingStartedRunning = false

    var providersStoppedWithError = false

    var worldSensingAuthorizationStatus = ARKitSession.AuthorizationStatus.notDetermined

    func startTracking() async -> ObjectTrackingProvider? {
        let referenceObjects = referenceObjectLoader.enabledReferenceObjects

        guard !referenceObjects.isEmpty else {
            print("No reference objects to start tracking")
            return nil
        }

        // Run a new provider every time when entering the immersive space.
        let objectTracking = ObjectTrackingProvider(referenceObjects: referenceObjects)
        let worldTracking = WorldTrackingProvider()
        do {
            try await arkitSession.run([objectTracking, worldTracking])
        } catch {
            print("Error: \(error)" )
            return nil
        }
        self.objectTracking = objectTracking
        self.worldTracking = worldTracking
        return objectTracking
    }

    var allRequiredAuthorizationsAreGranted: Bool {
        worldSensingAuthorizationStatus == .allowed
    }

    var allRequiredProvidersAreSupported: Bool {
        ObjectTrackingProvider.isSupported
    }

    var canEnterImmersiveSpace: Bool {
        allRequiredAuthorizationsAreGranted && allRequiredProvidersAreSupported
    }

    func requestWorldSensingAuthorization() async {
        let authorizationResult = await arkitSession.requestAuthorization(for: [.worldSensing])
        worldSensingAuthorizationStatus = authorizationResult[.worldSensing]!
    }

    func queryWorldSensingAuthorization() async {
        let authorizationResult = await arkitSession.queryAuthorization(for: [.worldSensing])
        worldSensingAuthorizationStatus = authorizationResult[.worldSensing]!
    }

    func monitorSessionEvents() async {
        for await event in arkitSession.events {
            switch event {
            case .dataProviderStateChanged(let providers, let newState, let error):
                switch newState {
                case .initialized:
                    break
                case .running:
                    guard objectTrackingStartedRunning == false, let objectTracking else { continue }
                    for provider in providers where provider === objectTracking {
                        objectTrackingStartedRunning = true
                        break
                    }
                case .paused:
                    break
                case .stopped:
                    guard objectTrackingStartedRunning == true, let objectTracking else { continue }
                    for provider in providers where provider === objectTracking {
                        objectTrackingStartedRunning = false
                        break
                    }
                    if let error {
                        print("An error occurred: \(error)")
                        providersStoppedWithError = true
                    }
                @unknown default:
                    break
                }
            case .authorizationChanged(let type, let status):
                print("Authorization type \(type) changed to \(status)")
                if type == .worldSensing {
                    worldSensingAuthorizationStatus = status
                }
            default:
                print("An unknown event occurred \(event)")
            }
        }
    }
}
